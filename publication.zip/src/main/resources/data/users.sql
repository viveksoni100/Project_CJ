/*
SQLyog Ultimate v12.09 (64 bit)
MySQL - 5.6.37 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

insert into `ease_users` (`id`, `created_at`, `status`, `updated_at`,  `email`, `first_name`, `last_name`, `password`, `phone`, `profile_picture`, `country_id`, `username`) values('1','2019-01-24 14:32:15',b'1','2019-01-24 14:32:15','anand4686@gmail.com','Anand','Panchal','$2a$10$5xixk3l3PssLXWFM0/OE6eFR0.1ONnR70oR0Yx1P6lkcHwz8vckSC','9865321245',NULL, 1, 'anand4686');
