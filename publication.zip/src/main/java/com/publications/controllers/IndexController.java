package com.publications.controllers;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.publications.entities.forms.ResetPasswordForm;
import com.publications.entities.pdf.PdfMark;
import com.publications.entities.publications.Publications;
import com.publications.entities.user.*;
import com.publications.events.event.ForgotPasswordEvent;
import com.publications.events.event.RegistrationEvent;
import com.publications.repositories.iface.user.ForgotPasswordRepository;
import com.publications.repositories.iface.user.UserRepository;
import com.publications.repositories.iface.user.VerificationRepository;
import com.publications.utilities.singleton.CommonUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.thymeleaf.model.IModel;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;

@Controller
@RequestMapping(value = "/")
public class IndexController extends AbstractBaseController {


    public final static Logger LOG = LogManager.getLogger(IndexController.class.getName());

    @Autowired
    private VerificationRepository verificationRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ForgotPasswordRepository forgotPasswordRepository;


    @Value("${eventbrite.api.token}")
    private String eventBrite;

    public static final String baseTemplate = "user/";
    public static final String redirect = "redirect:/";


    @GetMapping(value = {"home", ""})
    public String home(ModelMap model) {
        String pdfMarkList = "";
        try {
            SubUser subUser = userUtil.getCurrentSubuser();
            ObjectMapper mapper = new ObjectMapper();
            Publications publications = publicationsRepository.findFirstById(1l);
            List<PdfMark> pdfMarks = pdfMarkRepository.findAllByPublicationsAndSubUser_ParentUserAndStatus(publications, subUser.getParentUser(), true);
            if (pdfMarks != null && pdfMarks.size() > 0) {
                pdfMarkList = mapper.writeValueAsString(pdfMarks);
            }
        } catch (Exception e) {

        }
        model.addAttribute("pdfMarks", pdfMarkList);
        return "home";
    }


    /**
     * @param error
     * @param type
     * @param logout
     * @param page
     * @param model
     * @param user
     * @param redirectAttributes
     * @param request
     * @param httpSession
     * @return
     * @throws IOException
     */
    @RequestMapping(value = {"/login"}, method = RequestMethod.GET)
    public String login(@RequestParam(value = "error", required = false) String error,
                        @RequestParam(value = "type", required = false) String type,
                        @RequestParam(value = "logout", required = false) String logout,
                        @RequestParam(value = "page", required = false) String page,
                        ModelMap model, User user, RedirectAttributes redirectAttributes, HttpServletRequest request, HttpSession httpSession) throws IOException {

        //alerts.clearAlert();
        Authentication auth = userUtil.getAuthentication();

        if (!(auth instanceof AnonymousAuthenticationToken)) {
            httpSession.setAttribute("isSessionActive", "true");
            return "redirect:/home";
        }
        // Check if there is an error while loggin in
        if (error != null) {

            if (type != null && type.equalsIgnoreCase("captcha")) { // Throw captcha error if captcha validation failed
                alerts.setError("Captch.required");
                model.addAttribute("captchaTokenError", "Captcha required");
            } else if (type != null && type.equalsIgnoreCase("status")) { // throw user status error if user is still not enabled
                alerts.setError("user.status.disabled");
            } else if (type != null && type.equalsIgnoreCase("packageExpired")) {
                alerts.setError("user.package.expired");
                return "redirect:/payment";
            } else
                alerts.setError("Incorrect.login");

            alerts.setAlertModelAttribute(model);
        }

        String verification = request.getParameter("verification");
        if (verification != null && verification.equalsIgnoreCase("success")) {
            alerts.setSuccess("verification.success");
            alerts.setAlertModelAttribute(model);
        }
        model.addAttribute("loginCssClass", "active");
        alerts.clearAlert();
        //alerts.setAlertRedirectAttribute(redirectAttributes);
        return "user/login";
    }


    /**
     * @param request
     * @param redirectAttributes
     * @param model
     * @return
     */
    @GetMapping(value = "register")
    public String register(HttpServletRequest request, RedirectAttributes redirectAttributes, ModelMap model) {
        model.addAttribute("user", new User());
        return "user/register";
    }


    @GetMapping(value = "/aerror")
    public String error() {
        return "404";
    }


    /**
     * @param user
     * @param result
     * @param request
     * @param redirectAttributes
     * @param model
     * @return
     */
    @PostMapping(value = "register")
    public String postRegister(@Valid @ModelAttribute("user") User user, BindingResult result, HttpServletRequest request, RedirectAttributes redirectAttributes, ModelMap model) {
        String ret = "redirect:/login";
        try {
            if (result.hasErrors()) {
                model.addAttribute("user", user);
                alerts.setError("Required fields missing");
                ret = "user/register";
            } else {
                try {
                    // Get default role
                    UserRole role = roleRepository.findByRole(serviceUtil.getDefaultRole());
                    List<UserRole> userRoles = new ArrayList<>();
                    userRoles.add(role);
                    user.setUserRoles(userRoles);
                    // Set encoded password
                    user.setPassword(passwordEncoder.encode(user.getPassword()));
                    user.setUserRoles(userRoles);
                    // Save user
                    userRepository.save(user);

                    //Sending verification link
                    eventPublisher.publishEvent(new RegistrationEvent(user));
                    alerts.setSuccess("registration.success");
                } catch (Exception e) {
                    LOG.error("Error saving user ", e);
                }
            }
        } catch (Exception e) {
            alerts.setError("user.save.error");
            model.addAttribute("user", user);
            LOG.error("Error saving user ", e);
            ret = "user/register";
        }
        alerts.setAlertModelAttribute(model);
        alerts.setAlertRedirectAttribute(redirectAttributes);
        alerts.clearAlert();
        return ret;
    }


    @GetMapping(value = {"registration/email/verification"})
    public String verification(@RequestParam("token") String token, HttpServletRequest request, RedirectAttributes redirectAttributes, ModelMap model) {
        String ret = redirect + "login";
        try {

            VerificationToken verificationToken = verificationRepository.findFirstByToken(token);
            if (verificationToken == null) { // if null redirect back
                alerts.setError("token.verification.error");
            } else {


                // Get user from verification token
                User verificationTokenUser = verificationToken.getUser();
                Calendar cal = Calendar.getInstance();

                // check if token is still valid
                // if not redirect back and ask to generate token again
                Duration diff = Duration.between(LocalDateTime.now(), verificationToken.getExpiryDate());
                if (diff.isNegative()) {
                    String[] args = new String[2];
                    args[0] = serviceUtil.getBaseUrl() + "/resendlink";
                    args[1] = "Resend token";
                    alerts.setError("token.expired", args);
                    //alerts.setAlertRedirectAttribute(redirectAttributes);
                } else {

                    // if verification successful set user status to enabled
                    //verificationTokenUser.setEnabled(true);
                    verificationTokenUser.setStatus(true);
                    userRepository.save(verificationTokenUser);


                    //alerts.setSuccess("token.verification.success");
                    model.addAttribute("loginCssClass", "active");
                    //authWithAuthManager(servletRequest, verificationToken.getUser());
                    ret = "redirect:/login?verification=success";
                }
            }
        } catch (Exception e) {

        }
        alerts.setAlertRedirectAttribute(redirectAttributes);
        alerts.setAlertModelAttribute(model);
        alerts.clearAlert();
        return ret;
    }

    @GetMapping(value = {"forgot/password"})
    public String orgotPassword(@RequestParam("userEmail") String email, ModelMap model, RedirectAttributes redirectAttributes) {
        try {
            if (email != null && CommonUtil.isEmailIdValid(email)) {
                User user = userRepository.findFirstByEmail(email);
                if (user != null) {
                    ForgotPasswordToken forgotPasswordToken = forgotPasswordRepository.findFirstByUser(user);
                    LocalDateTime expiryDateTime = LocalDateTime.now().plusMinutes(Long.parseLong(environment.getProperty("forgot.password.expiry.minutes")));
                    if (forgotPasswordToken == null) {
                        forgotPasswordToken = new ForgotPasswordToken();
                        forgotPasswordToken.setUser(user);
                    }
                    forgotPasswordToken.setToken(CommonUtil.generateToken());
                    forgotPasswordToken.setExpiryDate(expiryDateTime);
                    forgotPasswordToken.setStatus(true);
                    forgotPasswordRepository.save(forgotPasswordToken);
                    eventPublisher.publishEvent(new ForgotPasswordEvent(user, localeHelper.getCurrentLocale(), forgotPasswordToken));
                }
                alerts.setSuccess("forgot.password.link.sent");
            } else {
                alerts.setError("email.invalid.format");
            }
        } catch (Exception e) {
            LOG.error("Error generating forgot password link ", e);
        }
        alerts.setAlertModelAttribute(model);
        alerts.setAlertRedirectAttribute(redirectAttributes);
        alerts.clearAlert();
        return "redirect:/login";
    }


    @GetMapping(value = {"forgot/password/token"})
    public String resetPassword(@RequestParam(value = "token", defaultValue = "-") String token,
                                ModelMap model, RedirectAttributes redirectAttributes) {
        String ret = baseTemplate + "reset";
        ResetPasswordForm resetPasswordForm = new ResetPasswordForm();
        Boolean expired = false;
        try {
            resetPasswordForm.setToken(token);
            ForgotPasswordToken forgotPasswordToken = forgotPasswordRepository.findFirstByTokenAndStatus(token, true);
            if (forgotPasswordToken != null) {
                User user = forgotPasswordToken.getUser();
                model.addAttribute("user", user);
                ret = baseTemplate + "reset";
                resetPasswordForm.setUid(pathVariableEncrypt.encrypt(user.getId().toString()));
            } else {
                expired = true;
                alerts.setError("forgot.password.link.expired");
            }
        } catch (Exception e) {
            LOG.error("Error resetting password", e);
        }


        model.addAttribute("expired", expired);
        model.addAttribute("token", token);
        model.addAttribute("resetPasswordForm", resetPasswordForm);
        alerts.setAlertModelAttribute(model);
        alerts.setAlertRedirectAttribute(redirectAttributes);
        alerts.clearAlert();
        return ret;
    }


    @PostMapping(value = {"forgot/password/token"})
    public String resetPasswordSubmit(@Valid @ModelAttribute("resetPasswordForm") ResetPasswordForm resetPasswordForm,
                                      BindingResult result,
                                      ModelMap model, RedirectAttributes redirectAttributes) {
        String ret = baseTemplate + "reset";
        Boolean expired = false;
        try {
            if (result.hasErrors()) {
                alerts.setError("required.fields.missing");
            } else {

                if (resetPasswordForm.getPassword().equalsIgnoreCase(resetPasswordForm.getResetPassword())) {
                    ForgotPasswordToken forgotPasswordToken = forgotPasswordRepository.findFirstByTokenAndStatus(resetPasswordForm.getToken(), true);

                    Duration diff = Duration.between(LocalDateTime.now(), forgotPasswordToken.getExpiryDate());
                    if (diff.isNegative()) {
                        alerts.setError("forgot.password.link.expired");
                        expired = true;
                    } else {
                        if (forgotPasswordToken != null) {
                            User user = forgotPasswordToken.getUser();
                            if (user != null) {
                                user.setPassword(passwordEncoder.encode(resetPasswordForm.getPassword()));
                                userRepository.save(user);

                                forgotPasswordToken.setStatus(false);
                                forgotPasswordRepository.save(forgotPasswordToken);
                                alerts.setSuccess("password.reset.success");
                            } else {
                                alerts.setError("general.error.msg");
                            }
                        } else {
                            alerts.setError("forgot.password.link.expired");
                        }
                    }

                } else {
                    alerts.setError("password.retype.invalid");
                }
            }
        } catch (Exception e) {
            LOG.error("Error resetting password ", e);
        }
        model.addAttribute("expired", expired);
        alerts.setAlertModelAttribute(model);
        alerts.clearAlert();
        model.addAttribute("resetPasswordForm", resetPasswordForm);
        return ret;
    }


    @GetMapping(value = {"UI_flowpaper_desktop_flat"})
    public String getPdfhtml() {
        try {

        } catch (Exception e) {

        }
        return "UI_flowpaper_desktop_flat";
    }

    @GetMapping(value = {"UI_flowpaper_mobile"})
    public String getPdfhtmlMobile() {
        try {

        } catch (Exception e) {

        }
        return "UI_flowpaper_mobile";
    }
}
