package com.publications.mail;

public abstract  class BaseMail {
}
