package com.publications.controllers;


import com.publications.entities.configurations.Configurations;
import com.publications.entities.publications.Publications;
import com.publications.entities.publications.PublicationsCategory;
import com.publications.entities.subscriptions.Notifications;
import com.publications.repositories.iface.config.ConfigRepository;
import com.publications.repositories.iface.publications.PublicationsCategoryRepository;
import com.publications.repositories.iface.publications.PublicationsRepository;
import com.publications.repositories.iface.subscriptions.NotificationsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.management.remote.NotificationResult;
import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value = {"/admin"})
@PreAuthorize("hasRole('ROLE_ADMIN')")
public class SuperAdminController extends AbstractBaseController {

    @Autowired
    private ConfigRepository configRepository;

    @Autowired
    private PublicationsCategoryRepository publicationsCategoryRepository;

    @Autowired
    private PublicationsRepository publicationsRepository;

    @Autowired
    private NotificationsRepository notificationsRepository;

    public static String baseTemplate = "admin/superadmin/";

    @GetMapping(value = {"/home"})
    public String home() {
        try {

        } catch (Exception e) {

        }
        return baseTemplate + "users/profile";
    }

    @GetMapping(value = {"/config/list"})
    public String configuration(@PageableDefault(page = 0, size = 10, sort = "createdAt", direction = Sort.Direction.ASC) Pageable pageable,
                                HttpServletRequest request, ModelMap model, RedirectAttributes redirectAttributes) {
        String ret = baseTemplate + "config/list";
        try {
            Page<Configurations> configs = configRepository.findAll(pageable);
            model.addAttribute("configs", configs);
            model.addAttribute("pagingUrl", "/ajax/super/paging/config");
            model.addAttribute("pageable", pageable);
        } catch (Exception e) {


        }
        return ret;
    }


    @GetMapping(value = {"/category/list"})
    public String category(@PageableDefault(page = 0, size = 10, sort = "createdAt", direction = Sort.Direction.ASC) Pageable pageable,
                           HttpServletRequest request, ModelMap model, RedirectAttributes redirectAttributes) {
        String ret = baseTemplate + "publications/category/list";
        try {
            Page<PublicationsCategory> categories = publicationsCategoryRepository.findAll(pageable);
            model.addAttribute("categories", categories);
            model.addAttribute("pagingUrl", "/ajax/super/paging/category");
            model.addAttribute("pageable", pageable);
        } catch (Exception e) {


        }
        return ret;
    }


    @GetMapping(value = {"/publications/list"})
    public String publications(@PageableDefault(page = 0, size = 10, sort = "createdAt", direction = Sort.Direction.DESC) Pageable pageable,
                               HttpServletRequest request, ModelMap model, RedirectAttributes redirectAttributes) {
        String ret = baseTemplate + "publications/list";
        try {
            Page<Publications> publications = publicationsRepository.findAll(pageable);
            model.addAttribute("publications", publications);
            model.addAttribute("pagingUrl", "/ajax/super/paging/publications");
            model.addAttribute("pageable", pageable);
        } catch (Exception e) {


        }
        return ret;
    }


    @GetMapping(value = {"/notification/list"})
    public String notification(@PageableDefault(page = 0, size = 10, sort = "createdAt", direction = Sort.Direction.ASC) Pageable pageable,
                               HttpServletRequest request, ModelMap model, RedirectAttributes redirectAttributes) {
        String ret = baseTemplate + "subscription/notifications";
        try {
            Page<Notifications> notifications = notificationsRepository.findAll(pageable);
            model.addAttribute("notifications", notifications);
            model.addAttribute("pagingUrl", "/ajax/super/paging/notification");
            model.addAttribute("pageable", pageable);
        } catch (Exception e) {


        }
        return ret;
    }


}
