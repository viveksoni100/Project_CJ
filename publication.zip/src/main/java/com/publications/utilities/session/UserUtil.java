package com.publications.utilities.session;

import com.publications.entities.security.RequestUserDetails;
import com.publications.entities.user.BaseUser;
import com.publications.entities.user.SubUser;
import com.publications.entities.user.User;
import com.publications.entities.user.VerificationToken;
import com.publications.mail.Mail;
import com.publications.repositories.iface.user.SubUserRepository;
import com.publications.services.EmailService;
import com.publications.utilities.base.BaseServiceUtil;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.*;


@Getter
@Setter
public class UserUtil extends BaseServiceUtil {
    public final static Logger LOG = LogManager.getLogger(UserUtil.class.getName());


    @Autowired
    protected EmailService emailService;

    @Autowired
    protected SubUserRepository subUserRepository;

    Integer subuserCount = null;
    Integer allowedSubusersCount = null;


    public boolean sendVerificationLink(User user, VerificationToken token) {
        try {


            Map<String, Object> model = new HashMap<>();
            model.put("name", user.getFirstName());
            model.put("verificationToken", token.getToken());
            model.put("appName", this.getAppName());

            Mail mail = new Mail();
            mail.setFrom(environment.getProperty("from.email"));
            mail.setTo(user.getEmail());
            mail.setSubject(this.getAppName() + " registration verification email");
            mail.setModel(model);

            emailService.sendEmail(mail, "mail/user/verification");

            return true;
        } catch (Exception e) {
            LOG.error("Error sending verification link " + user.getEmail(), e);
        }
        return false;
    }

    public Authentication getAuthentication() {
        return SecurityContextHolder.getContext().getAuthentication();
    }

   /* public User getCurrentUser() {
        User user = null;
        try {
            user = userRepository.findFirstByEmail(getAuthentication().getName());
        } catch (Exception e) {
        }
        return user;
    }*/

    public Integer getSubUserCount() {

        try {
            if (this.subuserCount == null) {
                User currentUser = this.getCurrentUser();
                this.subuserCount = subUserRepository.countByParentUser(currentUser);
                return this.subuserCount;
            }
        } catch (Exception e) {
            LOG.error("Error getting sub user count");
        }
        return 0;
    }


    public Integer getAllowedSubUserCount() {

        try {
            if (this.allowedSubusersCount == null) {
                User currentUser = this.getCurrentUser();
                this.subuserCount = subUserRepository.countByParentUser(currentUser);
                return this.subuserCount;
            }
        } catch (Exception e) {
            LOG.error("Error getting sub user count");
        }
        return 0;
    }


    public User getCurrentUser() {
        User user = null;
        try {
            Integer userType = ((RequestUserDetails) getAuthentication().getPrincipal()).getPersonId();
            if (userType.equals(1)) {
                user = userRepository.findFirstByEmail(getAuthentication().getName());
            } else {
                SubUser subUser = subUserRepository.findFirstByEmail(getAuthentication().getName());
                user = subUser.getParentUser();
            }
        } catch (Exception e) {
        }
        return user;
    }

    public SubUser getCurrentSubuser() {
        SubUser subuser = new SubUser();
        subuser.setId(0l);
        try {
            if (isSubuser())
                return subUserRepository.findFirstByEmail(getRequestUserDetails().getUsername());
            else {
                String email = this.getCurrentUser().getEmail();
                subuser = subUserRepository.findFirstByEmail(email);
            }
        } catch (Exception e) {
            LOG.error("error getting current subuser", e);
        }
        return subuser;
    }

    public boolean isSubuser() {
        BaseUser user = new User();
        try {
            Authentication authentication = getAuthentication();
            Integer userType = ((RequestUserDetails) authentication.getPrincipal()).getPersonId();
            if (userType.equals(1)) {
                return false;
            } else {
                return true;
            }
        } catch (Exception e) {
            LOG.error("error getting if usertype is subuser or user", e);
        }
        return false;

    }


    public RequestUserDetails getRequestUserDetails() {
        BaseUser user = new User();
        try {
            Authentication authentication = getAuthentication();
            LOG.error("Authentication object " + authentication.getName());
            return ((RequestUserDetails) authentication.getPrincipal());
        } catch (Exception e) {
            LOG.error("error getting RequestUserDetails object", e);
        }
        return null;

    }


    public void addAuthority(String authority) {
        try {
            Authentication auth = getAuthentication();

            Set<GrantedAuthority> updatedAuthorities = new HashSet<>(auth.getAuthorities());
            updatedAuthorities.add(new SimpleGrantedAuthority(authority)); //add your role here [e.g., new SimpleGrantedAuthority("ROLE_NEW_ROLE")]
            Authentication newAuth = new UsernamePasswordAuthenticationToken(auth.getPrincipal(), auth.getCredentials(), updatedAuthorities);
            SecurityContextHolder.getContext().setAuthentication(newAuth);
        } catch (Exception e) {
            LOG.error("Error adding authority ", e);
        }
    }

    public void removeAuthority(String authority) {
        try {
            Authentication auth = getAuthentication();

            Set<GrantedAuthority> updatedAuthorities = new HashSet<>(auth.getAuthorities());
            updatedAuthorities.remove(new SimpleGrantedAuthority(authority)); //add your role here [e.g., new SimpleGrantedAuthority("ROLE_NEW_ROLE")]
            Authentication newAuth = new UsernamePasswordAuthenticationToken(auth.getPrincipal(), auth.getCredentials(), updatedAuthorities);
            SecurityContextHolder.getContext().setAuthentication(newAuth);
        } catch (Exception e) {

        }
    }
}
