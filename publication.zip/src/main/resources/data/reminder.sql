INSERT INTO `subscription_notifications` (id, created_at, status, updated_at, days, email, sms, notification_type, task_id)
VALUES (1, '2019-08-23 12:20:44', 1, '2019-08-23 12:43:51', '1', 1, 0,
        'Daily Email Reminder1', 'DAYS'),
       (2, '2019-08-23 12:44:11', 1, '2019-08-23 14:33:31', '1', 0, 1,
        'Daily SMS Reminder', NULL),
       (3, '2019-08-23 14:01:05',1, '2019-08-23 14:01:22', '1', 1, 0,
        'Monthly email reminder', 'MONTHS');
