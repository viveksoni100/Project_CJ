package com.publications.task.base;

public abstract class AbstractBaseTask implements BaseTask{
}
