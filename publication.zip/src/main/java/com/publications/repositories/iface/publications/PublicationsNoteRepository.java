package com.publications.repositories.iface.publications;


import com.publications.entities.publications.Publications;
import com.publications.entities.publications.PublicationsNote;
import com.publications.entities.user.SubUser;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 */
public interface PublicationsNoteRepository extends JpaRepository<PublicationsNote, Long> {


    PublicationsNote findFirstById(Long id);

    PublicationsNote findFirstByPublicationsAndSubUser(Publications publications, SubUser subUser);

}
