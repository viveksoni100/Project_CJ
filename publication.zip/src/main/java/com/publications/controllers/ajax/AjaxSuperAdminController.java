package com.publications.controllers.ajax;


import com.publications.components.ajax.AjaxResponse;
import com.publications.components.encrypter.PathVariableEncrypt;
import com.publications.constants.Constants;
import com.publications.controllers.AbstractBaseController;
import com.publications.entities.configurations.Configurations;
import com.publications.entities.publications.Publications;
import com.publications.entities.publications.PublicationsCategory;
import com.publications.entities.subscriptions.Notifications;
import com.publications.repositories.iface.config.ConfigRepository;
import com.publications.repositories.iface.publications.PublicationsCategoryRepository;
import com.publications.repositories.iface.publications.PublicationsRepository;
import com.publications.repositories.iface.subscriptions.NotificationsRepository;
import com.publications.utilities.singleton.CommonUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;
import java.util.*;

@PreAuthorize("hasRole('ROLE_ADMIN')")
@Controller
@RequestMapping(value = {"/ajax/super"})
public class AjaxSuperAdminController extends AbstractBaseController {

    @Autowired
    private ConfigRepository configRepository;

    @Autowired
    private NotificationsRepository notificationsRepository;

    @Autowired
    private PublicationsCategoryRepository publicationsCategoryRepository;

    @Autowired
    private PublicationsRepository publicationsRepository;

    @Autowired
    private PathVariableEncrypt pathVariableEncrypt;


    public final static Logger LOG = LogManager.getLogger(AjaxSuperAdminController.class.getName());

    @GetMapping(value = {"/config/form", "/config/form/{id}"})
    public String colleagueForm(HttpServletRequest request, ModelMap model,
                                @PathVariable Optional<String> id
    ) {

        Configurations config = new Configurations();
        List<Long> roleIds = new ArrayList<>();
        if (id.isPresent()) {
            config = configRepository.findFirstById(pathVariableEncrypt.decryptId(id.get()));
        }
        model.addAttribute("config", config);
        model.addAttribute("success", false);

        return "ajax/super/config/create";
    }


    @PostMapping(value = {"/config/create", "/config/create/{id}"})
    public String colleague(@ModelAttribute("config") Configurations config, BindingResult result,
                            @PathVariable Optional<String> id,
                            HttpServletRequest request, ModelMap model, RedirectAttributes redirectAttributes) {


        try {

            if (id.isPresent() && !id.get().equalsIgnoreCase("0")) {
                Configurations configDb = configRepository.findFirstById(pathVariableEncrypt.decryptId(id.get()));
                config.setId(configDb.getId());
            }
            Set<ConstraintViolation<Configurations>> violations = validator.validate(config);
            if (violations.size() > 0) {
                for (ConstraintViolation violation : violations) {
                    result.rejectValue(violation.getPropertyPath().toString(), "", violation.getMessage());
                }
                model.addAttribute("success", false);
                alerts.setError("required.fields.missing");
            } else {
                configRepository.save(config);
                alerts.setSuccess("config.create.success");
                model.addAttribute("success", true);
            }
        } catch (Exception e) {
            model.addAttribute("success", false);
            alerts.setError("general.error.msg");
        }
        alerts.setAlertModelAttribute(model);
        alerts.clearAlert();
        model.addAttribute("config", config);

        return "ajax/super/config/create";
    }


    @ResponseBody
    @PostMapping(value = {"/config/change/{id}"})
    public AjaxResponse configChange(@PathVariable("id") String id, @RequestParam("configVaue") String value, HttpServletRequest request) {
        AjaxResponse response = new AjaxResponse();
        try {
            Configurations config = configRepository.findFirstById(pathVariableEncrypt.decryptId(id));
            if (config != null) {
                config.setConfigValue(value);
                configRepository.save(config);
                response.success("Data saved");
            }
        } catch (Exception e) {
            LOG.error("Error saving config", e);
            response.error("Error saving config");
        }
        return response;
    }

    @ResponseBody
    @PostMapping(value = {"/config/status/{id}"})
    public AjaxResponse configStatusChange(@PathVariable("id") String id, HttpServletRequest request) {
        AjaxResponse response = new AjaxResponse();
        try {
            Configurations config = configRepository.findFirstById(pathVariableEncrypt.decryptId(id));
            if (config != null) {
                config.setStatus(!config.getStatus());
                configRepository.save(config);
                response.success("Status changed", Arrays.asList(config.getStatus()));
            }
        } catch (Exception e) {
            LOG.error("Error saving config", e);
            response.error("Error saving config");
        }
        return response;
    }


    @GetMapping(value = {"/category/form", "/category/form/{id}"})
    public String categoryForm(HttpServletRequest request, ModelMap model,
                               @PathVariable Optional<String> id
    ) {

        PublicationsCategory publicationsCategory = new PublicationsCategory();

        if (id.isPresent()) {
            publicationsCategory = publicationsCategoryRepository.findFirstById(pathVariableEncrypt.decryptId(id.get()));
        }
        model.addAttribute("publicationsCategory", publicationsCategory);
        model.addAttribute("success", false);

        return "ajax/super/publications/category/create";
    }


    @PostMapping(value = {"/category/create", "/category/create/{id}"})
    public String category(@ModelAttribute("publicationsCategory") PublicationsCategory publicationsCategory, BindingResult result,
                           @PathVariable Optional<String> id,
                           HttpServletRequest request, ModelMap model, RedirectAttributes redirectAttributes) {


        try {

            if (id.isPresent() && !id.get().equalsIgnoreCase("0")) {
                PublicationsCategory categoryDb = publicationsCategoryRepository.findFirstById(pathVariableEncrypt.decryptId(id.get()));
                publicationsCategory.setId(categoryDb.getId());
            }
            Set<ConstraintViolation<PublicationsCategory>> violations = validator.validate(publicationsCategory);
            if (violations.size() > 0) {
                for (ConstraintViolation violation : violations) {
                    result.rejectValue(violation.getPropertyPath().toString(), "", violation.getMessage());
                }
                alerts.setError("required.fields.missing");
                model.addAttribute("success", false);
            } else {
                publicationsCategoryRepository.save(publicationsCategory);
                alerts.setSuccess("category.create.success");
                model.addAttribute("success", true);
            }
        } catch (Exception e) {
            model.addAttribute("success", false);
            alerts.setError("general.error.msg");
        }
        alerts.setAlertModelAttribute(model);
        alerts.clearAlert();
        model.addAttribute("config", publicationsCategory);

        return "ajax/super/publications/category/create";
    }


    @ResponseBody
    @PostMapping(value = {"/category/status/{id}"})
    public AjaxResponse categoryStatusChange(@PathVariable("id") String id, HttpServletRequest request) {
        AjaxResponse response = new AjaxResponse();
        try {
            PublicationsCategory category = publicationsCategoryRepository.findFirstById(pathVariableEncrypt.decryptId(id));
            if (category != null) {
                category.setStatus(!category.getStatus());
                publicationsCategoryRepository.save(category);
                response.success("Status changed", Arrays.asList(category.getStatus()));
            }
        } catch (Exception e) {
            LOG.error("Error saving category", e);
            response.error("Error saving category");
        }
        return response;
    }


    @GetMapping(value = {"/publications/form", "/publications/form/{id}"})
    public String publicationsForm(HttpServletRequest request, ModelMap model,
                                   @PathVariable Optional<String> id
    ) {
        List<Long> categories = new ArrayList<>();
        try {
            Publications publications = new Publications();

            if (id.isPresent()) {
                publications = publicationsRepository.findFirstById(pathVariableEncrypt.decryptId(id.get()));
                if (publications.getCategories() != null && publications.getCategories().size() > 0) {
                    for (PublicationsCategory cat : publications.getCategories()) {
                        categories.add(cat.getId());
                    }
                }
            }
            model.addAttribute("publications", publications);
            model.addAttribute("success", false);
        } catch (Exception e) {
            LOG.error("Error getting publication create form", e);
        }
        model.addAttribute("categories", categories);

        return "ajax/super/publications/create";
    }


    @PostMapping(value = {"/publications/create", "/publications/create/{id}"})
    public String publications(@ModelAttribute("publications") Publications publications, BindingResult result,
                               @RequestParam("lImage") MultipartFile labelPublicationOriginalImage,
                               @RequestParam("thumb") MultipartFile labelPublicationThumbnail,
                               @RequestParam("dImage") MultipartFile uploadDocfile,
                               @RequestParam("tImage") MultipartFile uploadTocFile,
                               @PathVariable Optional<String> id,
                               HttpServletRequest request, ModelMap model, RedirectAttributes redirectAttributes) {
        List<Long> categories = new ArrayList<>();
        boolean success = false;
        try {


            if (id.isPresent() && !id.get().equalsIgnoreCase("0")) {
                Publications publicationsDb = publicationsRepository.findFirstById(pathVariableEncrypt.decryptId(id.get()));
                publications.setId(publicationsDb.getId());
                publications.setLabelPublicationThumbnail(publicationsDb.getLabelPublicationThumbnail());
                publications.setLabelPublicationUploadDoc(publicationsDb.getLabelPublicationUploadDoc());
                publications.setLabelPublicationUploadToc(publicationsDb.getLabelPublicationUploadToc());
                publications.setLabelPublicationOriginalImage(publicationsDb.getLabelPublicationOriginalImage());
            }

            if (labelPublicationOriginalImage == null || labelPublicationThumbnail == null || uploadDocfile == null || uploadTocFile == null) {
                success = false;
                alerts.setError("required.fields.missing");
                alerts.setError("Please upload required files");
            } else {


                if (labelPublicationOriginalImage.isEmpty() && !id.isPresent()) {
                    publications.setLabelPublicationOriginalImage(null);
                } else if (!labelPublicationOriginalImage.isEmpty()) {
                    String imageFileName = fileStorageService.storeFile(labelPublicationOriginalImage, "image_", environment.getProperty("publication.path.image"));
                    publications.setLabelPublicationOriginalImage(imageFileName);
                    publications.setImageName(labelPublicationOriginalImage.getOriginalFilename());
                }

                if (labelPublicationThumbnail.isEmpty() && !id.isPresent()) {
                    publications.setLabelPublicationThumbnail(null);
                } else if (!labelPublicationThumbnail.isEmpty()) {
                    String thumbFileName = fileStorageService.storeFile(labelPublicationThumbnail, "thumb_", environment.getProperty("publication.path.thumb"));
                    publications.setLabelPublicationThumbnail(thumbFileName);
                    publications.setThumbnailName(labelPublicationThumbnail.getOriginalFilename());

                    String filePath = environment.getProperty("publication.path.thumb") + "/" + thumbFileName;
                    String newWidth = serviceUtil.getConfig(Constants.IMAGE_MAX_WIDTH_CONFIG, Constants.IMAGE_MAX_WIDTH_CONFIG_VAL);
                    String newHeight = serviceUtil.getConfig(Constants.IMAGE_MAX_HEIGHT_CONFIG, Constants.IMAGE_MAX_HEIGHT_CONFIG_VAL);
                    imageEditService.resizeWidthHeight(Integer.parseInt(newWidth), Integer.parseInt(newHeight), filePath, filePath);
                }


                if (uploadTocFile.isEmpty() && !id.isPresent()) {
                    publications.setLabelPublicationUploadToc(null);
                } else if (!uploadTocFile.isEmpty()) {
                    String tocFileName = fileStorageService.storeFile(uploadTocFile, "toc_", environment.getProperty("publication.path.image"));
                    publications.setTocName(uploadTocFile.getOriginalFilename());
                    publications.setLabelPublicationUploadToc(tocFileName);
                }


                if (uploadDocfile.isEmpty() && !id.isPresent()) {
                    publications.setLabelPublicationUploadDoc(null);
                } else if (!uploadDocfile.isEmpty()) {
                    String docFileName = fileStorageService.storeFile(uploadDocfile, "doc_", environment.getProperty("publication.path.image"));
                    publications.setDocName(uploadDocfile.getOriginalFilename());
                    publications.setLabelPublicationUploadDoc(docFileName);
                }


                Set<ConstraintViolation<Publications>> violations = validator.validate(publications);
                if (violations.size() > 0) {
                    for (ConstraintViolation violation : violations) {
                        result.rejectValue(violation.getPropertyPath().toString(), "", violation.getMessage());
                    }
                    success = false;
                    alerts.setError("required.fields.missing");

                } else {


                    publicationsRepository.save(publications);
                    alerts.setSuccess("publication.create.success");
                    success = true;
                }
            }

        } catch (Exception e) {
            success = false;
            alerts.setError("general.error.msg");
        }
        model.addAttribute("success", success);
        if (!success) {
            if (publications.getCategories() != null && publications.getCategories().size() > 0) {
                for (PublicationsCategory cat : publications.getCategories()) {
                    categories.add(cat.getId());
                }
            }
        }
        alerts.setAlertModelAttribute(model);
        alerts.clearAlert();
        model.addAttribute("config", publications);
        model.addAttribute("categories", categories);

        return "ajax/super/publications/create";
    }


    @PostMapping(value = {"/publications/copy/{id}"})
    @ResponseBody
    public AjaxResponse publicationsCopy(@PathVariable String id, HttpServletRequest request, ModelMap model, RedirectAttributes redirectAttributes) {
        AjaxResponse response = new AjaxResponse();
        try {
            Publications publications = publicationsRepository.findFirstById(pathVariableEncrypt.decryptId(id));
            Publications publicationsNew = new Publications();
            BeanUtils.copyProperties(publications, publicationsNew);
            publicationsNew.setId(0l);
            publicationsNew.setPublicationId(publications.getPublicationId() + " - " + publications.getPublicationId() + " copy");
            publicationsNew.setPublicationTitle(publications.getPublicationTitle());
            publicationsRepository.save(publicationsNew);
            response.success("Publication copied with publication id - " + publicationsNew.getPublicationId());
        } catch (Exception e) {
            response.error("Error while copying publications");
        }
        alerts.setAlertModelAttribute(model);
        alerts.clearAlert();
        return response;
    }


    @ResponseBody
    @PostMapping(value = {"/publications/status/{id}"})
    public AjaxResponse publicationsStatusChange(@PathVariable("id") String id, HttpServletRequest request) {
        AjaxResponse response = new AjaxResponse();
        try {
            Publications publications = publicationsRepository.findFirstById(pathVariableEncrypt.decryptId(id));
            if (publications != null) {
                publications.setStatus(!publications.getStatus());
                publicationsRepository.save(publications);
                response.success("Status changed", Arrays.asList(publications.getStatus()));
            }
        } catch (Exception e) {
            LOG.error("Error saving publication", e);
            response.error("Error saving publication");
        }
        return response;
    }


    /**
     * @param request
     * @param model
     * @param id
     * @return
     */
    @GetMapping(value = {"/notification/form", "/notification/form/{id}"})
    public String notificationForm(HttpServletRequest request, ModelMap model, @PathVariable Optional<String> id
    ) {

        Notifications notification = new Notifications();
        if (id.isPresent()) {
            notification = notificationsRepository.findFirstById(pathVariableEncrypt.decryptId(id.get()));
        }
        model.addAttribute("notifications", notification);
        model.addAttribute("success", false);
        return "ajax/super/notification/create";
    }


    @ResponseBody
    @PostMapping(value = {"/notification/status/{type}/{id}"})
    public AjaxResponse notificationStatusChange(@PathVariable("id") String id, @PathVariable("type") String type, HttpServletRequest request) {
        AjaxResponse response = new AjaxResponse();
        try {
            Notifications notification = notificationsRepository.findFirstById(pathVariableEncrypt.decryptId(id));
            if (notification != null) {
                switch (type.toLowerCase()) {
                    case "e":
                        notification.setEmail(!notification.isEmail());
                        response.success("Status changed", Arrays.asList(notification.isEmail()));
                        break;
                    case "m":
                        notification.setSms(!notification.isSms());
                        response.success("Status changed", Arrays.asList(notification.isSms()));
                        break;
                    case "s":
                        notification.setStatus(!notification.getStatus());
                        response.success("Status changed", Arrays.asList(notification.getStatus()));
                        break;
                }

                notificationsRepository.save(notification);

            }
        } catch (Exception e) {
            response = new AjaxResponse();
            LOG.error("Error saving category", e);
            response.error("Error saving category");
        }
        return response;
    }


    @PostMapping(value = {"/notification/create", "/notification/create/{id}"})
    public String notificationCreate(@ModelAttribute("notifications") Notifications notifications, BindingResult result,
                                     @PathVariable Optional<String> id,
                                     HttpServletRequest request, ModelMap model, RedirectAttributes redirectAttributes) {


        try {

            if (id.isPresent() && !id.get().equalsIgnoreCase("0")) {
                Notifications notificationsDb = notificationsRepository.findFirstById(pathVariableEncrypt.decryptId(id.get()));
                notifications.setId(notificationsDb.getId());
            }
            Set<ConstraintViolation<Notifications>> violations = validator.validate(notifications);
            if (violations.size() > 0) {
                CommonUtil.setViolations(violations, result, model, alerts);
                model.addAttribute("success", false);
            } else {
                notificationsRepository.save(notifications);
                alerts.setSuccess("notification.create.success");
                model.addAttribute("success", true);
            }
        } catch (Exception e) {
            model.addAttribute("success", false);
            alerts.setError("general.error.msg");
        }
        alerts.setAlertModelAttribute(model);
        alerts.clearAlert();
        model.addAttribute("notifications", notifications);

        return "ajax/super/notification/create";
    }
}
