package com.publications.events.event;

import com.publications.entities.user.User;
import com.publications.events.base.BaseEvent;
import lombok.Getter;
import lombok.Setter;
import org.springframework.context.ApplicationEvent;


@Getter
@Setter
public class RegistrationEvent extends ApplicationEvent implements BaseEvent {

    private User user;

    public RegistrationEvent(User user) {
        super(user);
        this.user = user;
    }
}
