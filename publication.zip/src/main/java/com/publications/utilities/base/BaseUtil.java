package com.publications.utilities.base;

public interface BaseUtil {
}
