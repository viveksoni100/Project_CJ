package com.publications.validator.Base;

public interface BaseConstraint {
}
