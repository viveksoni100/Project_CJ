package com.publications.events.event;

import com.publications.entities.user.SubUser;
import com.publications.entities.user.User;
import com.publications.events.base.BaseEvent;
import lombok.Getter;
import lombok.Setter;
import org.springframework.context.ApplicationEvent;


@Getter
@Setter
public class BeforeSubuserCreateEvent extends ApplicationEvent implements BaseEvent {

    private SubUser subUser;

    public BeforeSubuserCreateEvent(SubUser user) {
        super(user);
        this.subUser = user;
    }
}
