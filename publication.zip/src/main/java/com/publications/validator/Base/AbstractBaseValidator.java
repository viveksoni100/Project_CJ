package com.publications.validator.Base;

import com.publications.utilities.singleton.LocaleHelper;
import org.springframework.beans.factory.annotation.Autowired;

public abstract  class AbstractBaseValidator implements BaseConstraint{

    @Autowired
    protected LocaleHelper localeHelper;


}
