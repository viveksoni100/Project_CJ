insert into ease_roles (id, role_name, label) values(1, 'ROLE_ADMIN', 'Admin');
insert into ease_roles (id, role_name, label) values(2, 'ROLE_USER', 'User (Default)');
insert into ease_roles (id, role_name, label) values(3, 'ROLE_RECEPTIONIST', 'Receptionist');
insert into ease_roles (id, role_name, label) values(4, 'ROLE_COLLEAGUE', 'Colleague');
insert into ease_roles (id, role_name, label) values(5, 'ROLE_SUPERADMIN', 'Super');
insert into ease_roles (id, role_name, label) values(6, 'ROLE_EXPIRED', 'Expired');