INSERT INTO `configurations` (id, created_at, status, updated_at, config_name, config_value)
VALUES (1, '2019-08-01 17:17:55', 1, '2019-08-01 17:49:41', 'BASE_URL', 'http://127.0.0.1:8880'),
       (2, '2019-08-01 17:50:24', 1, '2019-08-02 15:27:09', 'FREE_TRIAL_DAYS', '30'),
       (3, '2019-08-12 14:42:47', 1, '2019-08-12 15:05:54', 'PER_USER_AMOUNT_MONTHLY', '10'),
       (4, '2019-08-12 15:06:09', 1, '2019-08-12 15:06:12', 'PER_USER_AMOUNT_YEARLY', '100');
