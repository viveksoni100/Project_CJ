package com.publications.repositories.iface.user;


import com.publications.entities.user.SubUser;
import com.publications.entities.user.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {



    User findFirstByEmail(String email);

    //User findFirstByUsername(String username);


    User findFirstByEmailAndIdNot(String email, Long id);

}
