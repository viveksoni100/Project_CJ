package com.publications.task.base;

public interface BaseTask {
}
