package com.publications.events.base;

public interface BaseEventListener {
}
