package com.publications.events.listener;

import com.publications.alerts.Alerts;
import com.publications.entities.user.SubUser;
import com.publications.entities.user.User;
import com.publications.events.base.BaseAbstractEventListener;
import com.publications.events.event.BeforeSubuserCreateEvent;
import com.publications.events.event.RegistrationEvent;
import com.publications.utilities.singleton.ServiceUtil;
import lombok.Getter;
import lombok.Setter;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
@Getter
@Setter
public class BeforeSubuserCreateListener extends BaseAbstractEventListener implements ApplicationListener<BeforeSubuserCreateEvent> {

    private SubUser user;

    @Autowired
    private ServiceUtil serviceUtil;

    @Autowired
    private Alerts alerts;

    @Override
    public void onApplicationEvent(BeforeSubuserCreateEvent event) {
        this.user = event.getSubUser();


    }




}
