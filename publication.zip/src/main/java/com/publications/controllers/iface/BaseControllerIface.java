package com.publications.controllers.iface;

public interface BaseControllerIface {
}
