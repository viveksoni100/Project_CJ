package com.publications.components.ajax;

public abstract  class BaseAjaxResponse {
}
