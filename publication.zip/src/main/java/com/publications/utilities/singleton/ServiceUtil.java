package com.publications.utilities.singleton;

import com.publications.constants.Constants;
import com.publications.entities.security.RequestUserDetails;
import com.publications.entities.user.BaseUser;
import com.publications.entities.user.User;
import com.publications.entities.user.VerificationToken;
import com.publications.utilities.base.BaseServiceUtil;
import com.publications.utilities.session.UserUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 * IMPORTANT NOTE : Please never use this class for specific user operations like updating or getting stored values in this class as this class is singleton class
 * and it will be used across the users and you may end getting wrong values ...
 * Thank you
 */

public class ServiceUtil extends BaseServiceUtil {

    public final static Logger LOG = LogManager.getLogger(ServiceUtil.class.getName());


    @Autowired
    private UserUtil userUtil;

    public Boolean sendVerificationLink(User user) {
        try {
            String token = CommonUtil.generateToken();

            VerificationToken verificationToken = new VerificationToken();
            verificationToken.setExpiryDate(CommonUtil.getExpiryDate(30));
            verificationToken.setToken(token);
            verificationToken.setUser(user);
            verificationRepository.save(verificationToken);

            return userUtil.sendVerificationLink(user, verificationToken);
        } catch (Exception e) {
            LOG.error("Error sending verification link email", e);
        }
        return false;
    }

    public String getDefaultRole() {
        try {
            return environment.getRequiredProperty("default.role");
        } catch (Exception e) {

        }
        return Constants.ROLE_CORPORATE;
    }

    public String getDefaultSubuserRole() {
        try {
            return environment.getRequiredProperty("default.role");
        } catch (Exception e) {

        }
        return Constants.ROLE_SUB_USER;
    }


    public Integer getSubscriptionAmount(String type, Integer count) {
        Integer amountPerUser = (type.equalsIgnoreCase("y")) ? Integer.parseInt(this.getConfig("PER_USER_AMOUNT_YEARLY")) : Integer.parseInt(this.getConfig("PER_USER_AMOUNT_MONTHLY"));
        return count * (amountPerUser) * 100;
    }



}
