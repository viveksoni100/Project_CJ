package com.publications.entities.forms.iface;

public interface BaseForm {
}
