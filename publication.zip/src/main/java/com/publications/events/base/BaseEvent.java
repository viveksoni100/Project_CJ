package com.publications.events.base;

public interface BaseEvent {
}
