package com.publications.entities.user;


import com.publications.entities.common.Country;
import com.publications.validator.iface.entity.UserConstraint;
import com.publications.validator.iface.field.HtmlValidateConstraint;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Set;


@Entity
@Table(name = "ease_users")
@UserConstraint
@Getter
@Setter
/*@UniqueUsername(classType = "User")*/
public class User extends BaseUser {


    @Column(name = "last_name")
    @NotEmpty
    @NotNull
    @HtmlValidateConstraint(whiteListType = "none")
    private String lastName;

    @Column(name = "first_name")
    @NotEmpty
    @NotNull
    @HtmlValidateConstraint(whiteListType = "none")
    private String firstName;


    @Column(name = "isd")
    @HtmlValidateConstraint(whiteListType = "none")
    private String isd;

    @Column(name = "phone")
    @HtmlValidateConstraint(whiteListType = "none")
    @NotEmpty
    @NotNull
    private String phone;


    @Column(name = "about")
    @HtmlValidateConstraint(whiteListType = "none")
    private String about;

    @ManyToMany(fetch = FetchType.EAGER)
    /*@JoinTable(name = "user_role", joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "role_id", referencedColumnName = "id"))*/
    @JoinTable(name = "user_role", joinColumns = {
            @JoinColumn(name = "user_id", nullable = false, updatable = false)},
            inverseJoinColumns = {@JoinColumn(name = "role_id",
                    nullable = false, updatable = false)})
    public List<UserRole> userRoles;


    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "user_rights", joinColumns = {
            @JoinColumn(name = "user_id", nullable = false, updatable = false)},
            inverseJoinColumns = {@JoinColumn(name = "right_id",
                    nullable = false, updatable = false)})
    public Set<UserRights> userRights;


    @NotEmpty
    @Transient
    private String confirmPassword;

    @Column(name = "profile_picture")
    private String profilePicture;

    @ManyToOne(targetEntity = Country.class, fetch = FetchType.EAGER)
    @JoinColumn(nullable = true, name = "country_id")
    private Country country;


    @PrePersist
    @Override
    public void preInsert() {
        super.preInsert();
        if (this.getPhone() == null)
            this.setPhone("");
    }

    public String getName() {
        return this.firstName + " " + this.lastName;
    }
}
