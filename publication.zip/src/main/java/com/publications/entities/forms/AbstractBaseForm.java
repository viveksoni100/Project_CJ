package com.publications.entities.forms;


import com.publications.entities.forms.iface.BaseForm;

public class AbstractBaseForm implements BaseForm {

}
