package com.publications.repositories.iface.user;


import com.publications.entities.user.VerificationToken;
import org.springframework.data.domain.Example;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 *
 */
public interface VerificationRepository extends JpaRepository<VerificationToken, Long> {

    VerificationToken findFirstByToken(String token);
}
