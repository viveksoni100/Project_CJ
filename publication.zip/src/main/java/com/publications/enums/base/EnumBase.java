package com.publications.enums.base;

public interface EnumBase {
}
