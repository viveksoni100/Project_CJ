package com.publications.events.listener;

import com.publications.alerts.Alerts;
import com.publications.entities.user.User;
import com.publications.events.base.BaseAbstractEventListener;
import com.publications.events.event.RegistrationEvent;
import com.publications.utilities.singleton.ServiceUtil;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
@Getter
@Setter
public class RegistrationListener extends BaseAbstractEventListener implements ApplicationListener<RegistrationEvent> {

    private User user;

    @Autowired
    private ServiceUtil serviceUtil;

    @Autowired
    private Alerts alerts;

    @Override
    public void onApplicationEvent(RegistrationEvent event) {
        this.user = event.getUser();
        sendEmail();

    }

    public void sendEmail() {
        boolean sent = serviceUtil.sendVerificationLink(user);
        if (sent) {
        } else {
            alerts.setError("Verification link not sent. Error sending email");
        }
    }


}
